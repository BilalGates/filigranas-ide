#!/usr/bin/env python3
"""Aplica el rediseño de Filigranas (secciones, blaugrana, divisores, panel
de Git con acciones y consumo de modelos) sobre el repositorio.

Uso, desde la raíz de filigranas-ide:
    python3 /ruta/a/filigranas-rediseno/aplicar.py

Cada archivo se trata así:
  · si no ha cambiado desde esta mañana, se sustituye por la versión nueva;
  · si ya es la versión nueva, se deja;
  · si alguien lo ha tocado entretanto, se fusiona con `git merge-file`
    (los dos cambios se conservan; si chocan, quedan marcas <<<<<<< y se avisa).
"""
import os, re, shutil, subprocess, sys, json

PKG = os.path.dirname(os.path.abspath(__file__))
REPO = os.getcwd()
if not os.path.exists(os.path.join(REPO, 'src-tauri', 'tauri.conf.json')):
    sys.exit('Ejecuta el script desde la raíz de filigranas-ide.')

read = lambda p: open(p, encoding='utf-8').read()
conflicts, done = [], []

for root, _, files in os.walk(os.path.join(PKG, 'nuevo')):
    for name in files:
        new = os.path.join(root, name)
        rel = os.path.relpath(new, os.path.join(PKG, 'nuevo'))
        cur = os.path.join(REPO, rel)
        base = os.path.join(PKG, 'base', rel)
        if not os.path.exists(cur):
            os.makedirs(os.path.dirname(cur), exist_ok=True)
            shutil.copyfile(new, cur); done.append(f'nuevo      {rel}'); continue
        if read(cur) == read(new):
            done.append(f'ya estaba  {rel}'); continue
        if not os.path.exists(base) or read(cur) == read(base):
            shutil.copyfile(new, cur); done.append(f'sustituido {rel}'); continue
        out = subprocess.run(['git', 'merge-file', '-p', cur, base, new], capture_output=True, text=True)
        open(cur, 'w', encoding='utf-8').write(out.stdout)
        if out.returncode:
            conflicts.append(rel); done.append(f'CONFLICTO  {rel}')
        else:
            done.append(f'fusionado  {rel}')

# lib.rs: registrar el módulo git_ops y sus comandos.
lib = os.path.join(REPO, 'src-tauri', 'src', 'lib.rs')
s = read(lib)
if 'git_ops' not in s:
    s = re.sub(r'^(mod window;)', r'mod git_ops;\n\1', s, count=1, flags=re.M) if re.search(r'^mod window;', s, re.M) \
        else re.sub(r'^((pub )?mod \w+;)', r'mod git_ops;\n\1', s, count=1, flags=re.M)
    cmds = ['git_fetch', 'git_pull', 'git_push', 'git_stash', 'git_stash_pop', 'git_stash_list', 'git_undo_commit']
    s = s.replace('tauri::generate_handler![', 'tauri::generate_handler![' + ''.join(f'\n            git_ops::{c},' for c in cmds), 1)
    open(lib, 'w', encoding='utf-8').write(s); done.append('editado    src-tauri/src/lib.rs (git_ops)')

# tauri.conf.json: ventana translúcida y oscura en macOS.
conf = os.path.join(REPO, 'src-tauri', 'tauri.conf.json')
c = read(conf)
c2 = c.replace('"transparent": false,', '"transparent": true,')
c2 = re.sub(r'\n\s*"backgroundColor": "#000000",', '', c2)
c2 = re.sub(r'"trafficLightPosition": \{[^}]*\}', '"trafficLightPosition": { "x": 20, "y": 18 }', c2)
if '"theme"' not in c2:
    c2 = c2.replace('"hiddenTitle": true,', '"hiddenTitle": true,\n        "theme": "Dark",', 1)
json.loads(c2)
if c2 != c:
    open(conf, 'w', encoding='utf-8').write(c2); done.append('editado    src-tauri/tauri.conf.json')

print('\n'.join(done))
if conflicts:
    print('\nRevisa las marcas <<<<<<< en:', ', '.join(conflicts))
else:
    print('\nListo. Prueba con: npm run tauri dev')
