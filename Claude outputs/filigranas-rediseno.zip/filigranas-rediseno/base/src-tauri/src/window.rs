use tauri::WebviewWindow;

/// La ventana es negra y opaca (fondo negro puro): no se aplica ningún
/// material translúcido. La transparencia queda para menús y popovers,
/// que la hacen con backdrop-filter dentro de la web.
pub fn apply_effects(window: &WebviewWindow) {
    let _ = window.set_background_color(Some(tauri::window::Color(0, 0, 0, 255)));
}
